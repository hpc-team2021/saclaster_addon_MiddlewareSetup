
import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
path = os.path.abspath("../..")
import sys
import json
sys.path.append(path + "/lib/others")
from API_method import get, post, put
from info_print import printout
import base64
import requests
import datetime
import logging

logger = logging.getLogger("sacluster").getChild(os.path.basename(__file__))
    
def external_data(auth_info, info_list = [1,0,0,0], fp = ""):
    
    _ = printout("loading external information ...", info_type = 0, info_list = info_list, fp = fp)
    logger.debug('loading external information')
    
    try:
        with open(path + "/lib/.Ex_info/External_info.json", "r") as f:
            data = json.load(f)
    
    except FileNotFoundError as e:
        _ = printout("EnvironmentalError: External_info.json does not exist under sacluster/lib/.Ex_info", info_type = 0, info_list = info_list, fp = fp)
        logger.critical('EnvironmentalError: External_info.json does not exist under sacluster/lib/.Ex_info')
        sys.exit()
    
    """
    if(api_index == True):
        server_info = {}
        disk_info = {}
        
        for zone,v in data["Zone"].items():
            server_info[zone] = {}
            
            count = 0
            while(True):
                res = get("https://secure.sakura.ad.jp/cloud/zone/"+zone+"/api/cloud/1.1/product/server", auth_info, payload={})
                if("ServerPlans" in res):
                    break
                if(count >= 5):
                    _ = printout("EnvironmentalError: server info can not be loaded by api\nYou should try after several minutes", info_type = 0, info_list = info_list, fp = fp)
                    sys.exit()
                
                count+=1
                      
            server_plans = res["ServerPlans"]
            for j in range(len(server_plans)):
                if(int(server_plans[j]["CPU"]) not in server_info[zone]):
                    server_info[zone][int(server_plans[j]["CPU"])] = {}
                server_info[zone][int(server_plans[j]["CPU"])][int(server_plans[j]["MemoryMB"])] = int(server_plans[j]["ID"])
            
            disk_info[zone] = {}
            
            while(True):
                res = get("https://secure.sakura.ad.jp/cloud/zone/"+zone+"/api/cloud/1.1/product/disk", auth_info, payload={})
                if("DiskPlans" in res):
                    break
                if(count >= 5):
                    _ = printout("EnvironmentalError: disk info can not be loaded by api\nYou should try after several minutes", info_type = 0, info_list = info_list, fp = fp)
                    sys.exit()
                
            disk_plans = res["DiskPlans"]
            for j in range(len(disk_plans)):
                if(disk_plans[j]["Name"] not in disk_info[zone]):
                    disk_info[zone][disk_plans[j]["Name"]] = []
                    
                for k in range(len(disk_plans[j]["Size"])):
                    disk_info[zone][disk_plans[j]["Name"]].append(disk_plans[j]["Size"][k]["SizeMB"])
            
        data["Server"] = server_info
        data["Disk"] = disk_info
    """
    
    return data

















































